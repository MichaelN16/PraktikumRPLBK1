import React, { Component } from "react";
class FirstChild extends Component {
 state = {
 angka: 0,
 tulisan: ''
 }

 tambahAngka = () => {
 this.setState((state) => { return { angka: state.angka + 1 } })
 }
 handleChange = (event) => {
 const { name, value } = event.target
 this.setState((state) => {
 return {
 [name]: value
 }
 })
 }
 render() {
 return (
 <>
 <div>
 <p>Aku anak pertama</p>
 </div>
 <button onClick={this.tambahAngka}>Coba Tambah!</button>
 <br />
 <span>{this.state.angka}</span>
 <br />
 <br />
 <br />
 <input onChange={this.handleChange} name='tulisan' 
value={this.state.tulisan} />
 <br />
 <span>{this.state.tulisan}</span>
 </>
 );
 }
}
export default FirstChild;