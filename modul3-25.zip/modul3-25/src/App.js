import React from 'react'; 
import './App.css';
import Parent from "./Components/Parent";
class App extends React.Component { 
render() {
return (
<div className="App">
<Parent />
</div>
)
}
}
export default App;
